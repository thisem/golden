#
# TABLE STRUCTURE FOR: dokter
#

DROP TABLE IF EXISTS `dokter`;

CREATE TABLE `dokter` (
  `id_dokter` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `spesialis` varchar(50) NOT NULL,
  `hp` varchar(20) NOT NULL,
  PRIMARY KEY (`id_dokter`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `dokter` (`id_dokter`, `nama`, `spesialis`, `hp`) VALUES ('2', 'Drs Novel', 'Umum', '0877');
INSERT INTO `dokter` (`id_dokter`, `nama`, `spesialis`, `hp`) VALUES ('3', 'Dr. Hasanul', 'Umum', '0853');


#
# TABLE STRUCTURE FOR: jurnal
#

DROP TABLE IF EXISTS `jurnal`;

CREATE TABLE `jurnal` (
  `nojurnal` varchar(20) NOT NULL,
  `notransaksi` varchar(20) NOT NULL,
  `nourut` int(3) NOT NULL,
  `tanggal` date NOT NULL,
  `debit` float NOT NULL,
  `kredit` float NOT NULL,
  `keterangan` text NOT NULL,
  `keterangan2` text NOT NULL,
  PRIMARY KEY (`nojurnal`,`notransaksi`,`nourut`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20181214/J/O/003', '20181127/S/001/WHD', '1', '2018-12-14', '0', '1000000', 'Pembelian Obat mixagrip [10]', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20181214/J/O/004', '1', '1', '2018-12-14', '0', '600000', 'Pembelian Obat Oskadon [60]', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20181214/J/P/002', '20181123/005/WHD', '1', '2018-12-14', '34000', '0', 'Biaya Checkup Rudi Syahputra', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20181214/J/P/002', '20181123/005/WHD', '2', '2018-12-14', '170000', '0', 'Biaya Obat Rudi Syahputra', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20181214/J/P/002', '20181123/005/WHD', '3', '2018-12-14', '17000', '0', 'Biaya Ppn Obat Rudi Syahputra', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20181215/J/O/001', '20181127/S/002/WHD', '1', '2018-12-15', '0', '10000', 'Pembelian Obat mixagrip [10]', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20181218/J/O/001', '20181127/S/003/WHD', '1', '2018-12-18', '0', '100000', 'Pembelian Obat mixagrip [10]', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190104/J/O/002', '20181127/S/004/WHD', '1', '2019-01-04', '0', '200000', 'Pembelian Obat mixagrip [10]', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190104/J/P/001', '20181117/005/WHD', '1', '2019-01-04', '45000', '0', 'Biaya Checkup adi syahputra', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190104/J/P/001', '20181117/005/WHD', '2', '2019-01-04', '1050000', '0', 'Biaya Obat adi syahputra', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190104/J/P/001', '20181117/005/WHD', '3', '2019-01-04', '105000', '0', 'Biaya Ppn Obat adi syahputra', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190109/J/P/001', '20190104/002/WHD', '1', '2019-01-09', '30000', '0', 'Biaya Checkup ', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190109/J/P/001', '20190104/002/WHD', '2', '2019-01-09', '210000', '0', 'Biaya Obat ', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190109/J/P/001', '20190104/002/WHD', '3', '2019-01-09', '21000', '0', 'Biaya Ppn Obat ', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190109/J/P/002', '20181123/004/WHD', '1', '2019-01-09', '35000', '0', 'Biaya Checkup Adi', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190109/J/P/002', '20181123/004/WHD', '2', '2019-01-09', '220000', '0', 'Biaya Obat Adi', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190109/J/P/002', '20181123/004/WHD', '3', '2019-01-09', '22000', '0', 'Biaya Ppn Obat Adi', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190118/J/P/001', '20181117/001/WHD', '1', '2019-01-18', '20000', '0', 'Biaya Checkup ANDRI MAULANA ST', 'Tunai  ');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190121/J/O/001', '20190121/S/002/WHD', '1', '2019-01-21', '0', '700000', 'Pembelian Obat Bodrexin cair [20]', '');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190121/J/P/002', '20181216/001/WHD', '1', '2019-01-21', '50000', '0', 'Biaya Checkup ffff', 'BPJS  1234567');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190121/J/P/002', '20181216/001/WHD', '2', '2019-01-21', '12000', '0', 'Biaya Obat ffff', 'BPJS  1234567');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190121/J/P/002', '20181216/001/WHD', '3', '2019-01-21', '1200', '0', 'Biaya Ppn Obat ffff', 'BPJS  1234567');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190121/J/P/003', '20181215/005/WHD', '1', '2019-01-21', '30000', '0', 'Biaya Checkup tesssss', '  ');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190121/J/P/003', '20181215/005/WHD', '2', '2019-01-21', '250000', '0', 'Biaya Obat tesssss', '  ');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190121/J/P/004', '20181118/001/WHD', '1', '2019-01-21', '50000', '0', 'Biaya Checkup TESSS', 'BPJS  1234321');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190121/J/P/004', '20181118/001/WHD', '2', '2019-01-21', '330000', '0', 'Biaya Obat TESSS', 'BPJS  1234321');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190122/J/P/001', '20190121/002/WHD', '1', '2019-01-22', '30000', '0', 'Biaya Checkup Andri Maulana ST', 'BPJS  123');
INSERT INTO `jurnal` (`nojurnal`, `notransaksi`, `nourut`, `tanggal`, `debit`, `kredit`, `keterangan`, `keterangan2`) VALUES ('20190122/J/P/001', '20190121/002/WHD', '2', '2019-01-22', '6000', '0', 'Biaya Obat Andri Maulana ST', 'BPJS  123');


#
# TABLE STRUCTURE FOR: menus
#

DROP TABLE IF EXISTS `menus`;

CREATE TABLE `menus` (
  `id_menu` int(10) NOT NULL AUTO_INCREMENT,
  `icon` text NOT NULL,
  `title` varchar(40) NOT NULL,
  `type` enum('title','click','href','dialogbox','none') NOT NULL,
  `parent` int(4) NOT NULL,
  `order` int(4) NOT NULL,
  `status` int(11) NOT NULL,
  `act` text NOT NULL,
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

INSERT INTO `menus` (`id_menu`, `icon`, `title`, `type`, `parent`, `order`, `status`, `act`) VALUES ('1', '<i class=\"fa fa-home\"></i>', 'Dashboard', 'title', '0', '0', '1', 'dashboard');
INSERT INTO `menus` (`id_menu`, `icon`, `title`, `type`, `parent`, `order`, `status`, `act`) VALUES ('3', '<i class=\"fa fa-caret-square-o-right\"></i>', 'Stock Obat', 'click', '0', '2', '1', 'obat');
INSERT INTO `menus` (`id_menu`, `icon`, `title`, `type`, `parent`, `order`, `status`, `act`) VALUES ('31', '<i class=\"fa fa-caret-square-o-right\"></i>', 'Pembayaran', 'click', '0', '4', '1', 'pembayaran');
INSERT INTO `menus` (`id_menu`, `icon`, `title`, `type`, `parent`, `order`, `status`, `act`) VALUES ('32', '<i class=\"fa fa-caret-square-o-right\"></i>', 'Pembelian Obat', 'click', '0', '2', '0', 'pembelian');
INSERT INTO `menus` (`id_menu`, `icon`, `title`, `type`, `parent`, `order`, `status`, `act`) VALUES ('33', '<i class=\"fa fa-caret-square-o-right\"></i>', 'Data Supplier', 'click', '0', '4', '0', 'pembelian');
INSERT INTO `menus` (`id_menu`, `icon`, `title`, `type`, `parent`, `order`, `status`, `act`) VALUES ('34', '<i class=\"fa fa-caret-square-o-right\"></i>', 'Report', 'click', '0', '5', '1', 'report');
INSERT INTO `menus` (`id_menu`, `icon`, `title`, `type`, `parent`, `order`, `status`, `act`) VALUES ('35', '<i class=\"fa fa-user-md\"></i>', 'Data Dokter', 'click', '0', '6', '1', 'dokter');
INSERT INTO `menus` (`id_menu`, `icon`, `title`, `type`, `parent`, `order`, `status`, `act`) VALUES ('36', '<i class=\"fa fa-user\"></i>', 'Pasien', 'click', '0', '1', '1', 'pasien');
INSERT INTO `menus` (`id_menu`, `icon`, `title`, `type`, `parent`, `order`, `status`, `act`) VALUES ('37', '<i class=\"fa fa-user\"></i>', 'Pemakaian Obat', 'click', '0', '3', '1', 'transaksiObat');
INSERT INTO `menus` (`id_menu`, `icon`, `title`, `type`, `parent`, `order`, `status`, `act`) VALUES ('38', '<i class=\"fa fa-gear\"></i>', 'Reset Password', 'click', '0', '7', '1', 'reset');


#
# TABLE STRUCTURE FOR: obat
#

DROP TABLE IF EXISTS `obat`;

CREATE TABLE `obat` (
  `id_obat` int(7) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `nm_obat` varchar(50) NOT NULL,
  `satuan` varchar(30) NOT NULL,
  `harga` int(8) NOT NULL,
  `expired` date NOT NULL,
  PRIMARY KEY (`id_obat`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `obat` (`id_obat`, `nm_obat`, `satuan`, `harga`, `expired`) VALUES ('0000002', 'Paracetamol', 'botol', '50000', '2020-06-21');
INSERT INTO `obat` (`id_obat`, `nm_obat`, `satuan`, `harga`, `expired`) VALUES ('0000003', 'Amoxilin', 'sachet', '30000', '2022-05-20');
INSERT INTO `obat` (`id_obat`, `nm_obat`, `satuan`, `harga`, `expired`) VALUES ('0000004', 'Antasida', 'papan', '15000', '2018-02-10');
INSERT INTO `obat` (`id_obat`, `nm_obat`, `satuan`, `harga`, `expired`) VALUES ('0000005', 'tes', 'tesss', '3000', '2020-10-24');
INSERT INTO `obat` (`id_obat`, `nm_obat`, `satuan`, `harga`, `expired`) VALUES ('0000006', 'Testing', 'sachet', '12000', '2019-01-21');
INSERT INTO `obat` (`id_obat`, `nm_obat`, `satuan`, `harga`, `expired`) VALUES ('0000007', 'Bodrexin cair', 'botol', '6000', '2026-03-01');


#
# TABLE STRUCTURE FOR: supply_obat
#

DROP TABLE IF EXISTS `supply_obat`;

CREATE TABLE `supply_obat` (
  `notransaksi` varchar(20) NOT NULL,
  `id_obat` int(7) unsigned zerofill NOT NULL,
  `tgl` date NOT NULL,
  `jumlah` int(10) NOT NULL,
  `harga_beli` int(8) NOT NULL,
  `keterangan` text NOT NULL,
  `status` char(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`notransaksi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20181127/S/001/WHD', '0000003', '2018-11-27', '10', '100000', 'tes', '1');
INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20181127/S/002/WHD', '0000003', '2018-11-27', '10', '1000', 'tes', '1');
INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20181127/S/003/WHD', '0000003', '2018-11-27', '10', '10000', 'tes', '1');
INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20181127/S/004/WHD', '0000003', '2018-11-27', '10', '20000', 'tessss', '1');
INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20181127/S/007/WHD', '0000003', '2018-11-27', '10', '100000', 'Koreksi Data Salah', '0');
INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20181127/S/008/WHD', '0000002', '2018-11-27', '10', '100000', 'tes', '0');
INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20181127/S/009/WHD', '0000002', '2018-12-23', '10', '10000', 'ss', '0');
INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20181127/S/010/WHD', '0000002', '2018-11-27', '10', '50000', 'tss', '0');
INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20181127/S/011/WHD', '0000003', '2018-11-27', '10', '1000', 'tes', '0');
INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20181127/S/012/WHD', '0000002', '2018-11-27', '10', '1000', 'tess', '0');
INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20181219/S/001/WHD', '0000004', '2018-12-19', '10', '3000', 'Kimia Farma', '0');
INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20181219/S/002/WHD', '0000004', '2018-12-19', '50', '3000', 'tes', '0');
INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20190121/S/001/WHD', '0000006', '2019-01-21', '250', '3000', 'PT. KALBE FARMA', '0');
INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20190121/S/002/WHD', '0000007', '2019-01-21', '20', '35000', 'TESS', '1');
INSERT INTO `supply_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `keterangan`, `status`) VALUES ('20190121/S/003/WHD', '0000007', '2019-01-21', '-10', '3000', 'tessss', '0');


#
# TABLE STRUCTURE FOR: sys_auth
#

DROP TABLE IF EXISTS `sys_auth`;

CREATE TABLE `sys_auth` (
  `id_user` int(10) NOT NULL,
  `id_menu` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_user`,`id_menu`),
  UNIQUE KEY `id_user` (`id_user`,`id_menu`),
  UNIQUE KEY `id_user_2` (`id_user`,`id_menu`),
  KEY `id_menu` (`id_menu`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('0', '1');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('0', '38');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('1', '1');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('1', '3');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('1', '31');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('1', '32');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('1', '33');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('1', '34');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('1', '35');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('1', '36');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('1', '37');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('2', '1');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('2', '35');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('2', '36');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('3', '31');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('3', '34');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('3', '36');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('4', '3');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('4', '36');
INSERT INTO `sys_auth` (`id_user`, `id_menu`) VALUES ('4', '37');


#
# TABLE STRUCTURE FOR: sys_users
#

DROP TABLE IF EXISTS `sys_users`;

CREATE TABLE `sys_users` (
  `id_user` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `lastip` varchar(15) NOT NULL,
  `lastlogin_as` varchar(45) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` char(2) NOT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `id_user` (`id_user`,`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `sys_users` (`id_user`, `username`, `password`, `lastip`, `lastlogin_as`, `lastupdate`, `status`) VALUES ('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', '', '', '2018-12-19 10:53:44', '1');
INSERT INTO `sys_users` (`id_user`, `username`, `password`, `lastip`, `lastlogin_as`, `lastupdate`, `status`) VALUES ('2', 'resepsionis', '827ccb0eea8a706c4c34a16891f84e7b', '', '', '2018-12-19 10:56:43', '1');
INSERT INTO `sys_users` (`id_user`, `username`, `password`, `lastip`, `lastlogin_as`, `lastupdate`, `status`) VALUES ('3', 'kasir', '827ccb0eea8a706c4c34a16891f84e7b', '', '', '2019-01-24 10:44:00', '1');
INSERT INTO `sys_users` (`id_user`, `username`, `password`, `lastip`, `lastlogin_as`, `lastupdate`, `status`) VALUES ('4', 'apoteker', '827ccb0eea8a706c4c34a16891f84e7b', '', '', '2018-12-19 11:07:28', '1');


#
# TABLE STRUCTURE FOR: transaksi
#

DROP TABLE IF EXISTS `transaksi`;

CREATE TABLE `transaksi` (
  `notransaksi` varchar(20) NOT NULL,
  `noantrian` int(3) unsigned zerofill NOT NULL,
  `nama` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `kelamin` char(1) NOT NULL,
  `hp` varchar(20) NOT NULL,
  `dokter` varchar(50) NOT NULL,
  `keluhan` text NOT NULL,
  `diagnosa` text NOT NULL,
  `tindakan` text NOT NULL,
  `biaya_checkup` int(10) NOT NULL,
  `biaya_ppn` int(10) NOT NULL,
  `biaya_total` int(10) NOT NULL,
  `tgl_in` date NOT NULL,
  `tgl_out` date NOT NULL,
  `tgl_byr` date NOT NULL,
  `jenis_bayar` varchar(30) NOT NULL,
  `no_jenis_bayar` varchar(50) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0:Antri, 1:checkup, 2:obat; 3:bayar, 4:batal',
  `soft_delete` char(1) NOT NULL,
  PRIMARY KEY (`notransaksi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20181117/001/WHD', '001', 'ANDRI MAULANA ST', '1993-12-04', 'L', '', 'Dr. Hasanul', 'tes', 'tessss', 'Suntik', '20000', '0', '20000', '2019-01-18', '0000-00-00', '2019-01-18', 'Tunai', '', '3', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20181117/005/WHD', '005', 'adi syahputra', '1995-12-01', 'L', '', 'Drs. Novel', '', '', 'Pengukuran Tensi Darah', '45000', '105000', '1200000', '2018-11-27', '0000-00-00', '2019-01-04', '', '', '3', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20181118/001/WHD', '006', 'TESSS', '0000-12-01', 'L', '', 'Dr. Hasanul', '', '', '', '50000', '0', '413000', '2019-01-21', '0000-00-00', '2019-01-21', 'BPJS', '1234321', '3', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20181121/001/WHD', '008', '', '0000-00-00', 'L', '', '', '', '', '', '0', '0', '0', '2018-11-21', '0000-00-00', '0000-00-00', '', '', '0', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20181121/002/WHD', '009', '', '0000-00-00', 'L', '', '', '', '', '', '0', '0', '0', '2018-11-21', '0000-00-00', '0000-00-00', '', '', '0', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20181123/003/WHD', '010', 'Nanda', '0000-12-01', 'L', '', 'Drs. Novel', '', '', '', '10000', '39000', '439000', '2018-12-13', '0000-00-00', '2018-12-13', '', '', '2', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20181123/004/WHD', '011', 'Adi', '0000-12-01', 'L', '', 'Drs. Novel', 'Sakit Kepala', 'Anemia', 'Suntik', '35000', '22000', '277000', '2018-12-15', '0000-00-00', '2019-01-09', '', '12345', '3', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20181123/005/WHD', '012', 'Rudi Syahputra', '0000-01-01', 'L', '', 'Drs. Novel', '', '', '', '34000', '17000', '221000', '2018-12-14', '0000-00-00', '2018-12-14', '', '', '3', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20181215/005/WHD', '005', 'tesssss', '1990-12-01', 'L', '', 'Dr. Hasanul', '', '', '', '30000', '0', '305000', '2019-01-04', '0000-00-00', '2019-01-21', '', '', '3', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20181216/001/WHD', '002', 'ffff', '1990-12-01', 'L', '', 'Dr. Hasanul', '', '', '', '50000', '1200', '63200', '2019-01-21', '0000-00-00', '2019-01-21', 'BPJS', '1234567', '3', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20181216/002/WHD', '003', 'gg', '1990-01-01', 'L', '', '', '', '', '', '0', '0', '0', '2018-12-16', '0000-00-00', '0000-00-00', '', '', '0', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20181219/001/WHD', '004', '', '1990-01-01', 'L', '', '', '', '', '', '0', '0', '0', '2018-12-19', '0000-00-00', '0000-00-00', '', '', '0', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20190104/001/WHD', '007', 'agus', '1990-01-01', 'L', '', '', '', '', '', '0', '0', '0', '2019-01-04', '0000-00-00', '0000-00-00', '', '', '0', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20190104/002/WHD', '011', '', '1990-01-01', 'L', '', 'Dr. Hasanul', 'pening', 'migrain', 'suntik', '30000', '21000', '261000', '2019-01-04', '0000-00-00', '2019-01-09', '', '', '3', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20190121/001/WHD', '001', 'adi', '1990-12-01', 'L', '', 'Dr. Hasanul', '', '', '', '0', '0', '0', '2019-01-24', '0000-00-00', '0000-00-00', 'Tunai', '', '1', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20190121/002/WHD', '002', 'Andri Maulana ST', '1990-12-01', 'L', '085360646693', 'Drs Novel', '', '', '', '30000', '0', '36600', '2019-01-22', '0000-00-00', '2019-01-22', 'BPJS', '123', '3', '');
INSERT INTO `transaksi` (`notransaksi`, `noantrian`, `nama`, `tgl_lahir`, `kelamin`, `hp`, `dokter`, `keluhan`, `diagnosa`, `tindakan`, `biaya_checkup`, `biaya_ppn`, `biaya_total`, `tgl_in`, `tgl_out`, `tgl_byr`, `jenis_bayar`, `no_jenis_bayar`, `status`, `soft_delete`) VALUES ('20190121/003/WHD', '005', 'Gafur', '1994-12-01', 'L', '0843', 'Dr. Hasanul', '', '', '', '0', '0', '0', '2019-01-21', '0000-00-00', '0000-00-00', 'Tunai', '', '1', '');


#
# TABLE STRUCTURE FOR: transaksi_obat
#

DROP TABLE IF EXISTS `transaksi_obat`;

CREATE TABLE `transaksi_obat` (
  `notransaksi` varchar(20) NOT NULL,
  `id_obat` int(7) unsigned zerofill NOT NULL,
  `tgl` date NOT NULL,
  `jumlah` int(3) NOT NULL,
  `harga_beli` int(8) NOT NULL,
  `harga` int(8) NOT NULL,
  PRIMARY KEY (`notransaksi`,`id_obat`),
  CONSTRAINT `relasi` FOREIGN KEY (`notransaksi`) REFERENCES `transaksi` (`notransaksi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181117/001/WHD', '0000002', '0000-00-00', '2', '0', '0');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181117/001/WHD', '0000003', '0000-00-00', '2', '0', '0');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181117/005/WHD', '0000002', '2019-01-04', '15', '0', '50000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181117/005/WHD', '0000003', '2019-01-04', '5', '0', '30000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181117/005/WHD', '0000004', '2019-01-04', '10', '0', '15000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181118/001/WHD', '0000002', '2019-01-21', '6', '0', '50000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181118/001/WHD', '0000003', '2019-01-21', '1', '0', '30000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181123/003/WHD', '0000002', '2018-12-23', '6', '0', '50000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181123/003/WHD', '0000003', '2018-12-23', '3', '0', '30000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181123/004/WHD', '0000002', '2018-12-23', '2', '0', '50000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181123/004/WHD', '0000004', '2018-12-23', '8', '0', '15000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181123/005/WHD', '0000002', '2018-12-23', '1', '0', '50000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181123/005/WHD', '0000003', '2018-12-23', '2', '0', '30000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181123/005/WHD', '0000004', '2018-12-23', '4', '0', '15000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181215/005/WHD', '0000002', '2019-01-21', '5', '0', '50000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181216/001/WHD', '0000007', '2019-01-21', '2', '0', '6000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181219/001/WHD', '0000003', '0000-00-00', '20', '0', '0');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20181219/001/WHD', '0000004', '0000-00-00', '38', '0', '0');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20190104/002/WHD', '0000002', '2019-01-09', '3', '0', '50000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20190104/002/WHD', '0000003', '2019-01-09', '2', '0', '30000');
INSERT INTO `transaksi_obat` (`notransaksi`, `id_obat`, `tgl`, `jumlah`, `harga_beli`, `harga`) VALUES ('20190121/002/WHD', '0000007', '2019-01-22', '1', '0', '6000');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `kd_user` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `alamat` text NOT NULL,
  `id_user` int(10) NOT NULL,
  `img` text NOT NULL,
  PRIMARY KEY (`kd_user`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`kd_user`, `nama`, `email`, `alamat`, `id_user`, `img`) VALUES ('1', 'Administrator', '', '', '1', 'admin.jpg');
INSERT INTO `users` (`kd_user`, `nama`, `email`, `alamat`, `id_user`, `img`) VALUES ('2', 'Resepsionis', '', '', '2', 'admin.jpg');
INSERT INTO `users` (`kd_user`, `nama`, `email`, `alamat`, `id_user`, `img`) VALUES ('3', 'Kasir', '', '', '3', 'admin.jpg');
INSERT INTO `users` (`kd_user`, `nama`, `email`, `alamat`, `id_user`, `img`) VALUES ('4', 'Apoteker', '', '', '4', 'admin.jpg');


